package com.thesis.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Pharmacy {
    private int id;
    //药房名称
    private String name;
    //药房面积
    private double area;
    //药房负责人
    private String principal;
    //负责人联系方式
    private String phone;
}
