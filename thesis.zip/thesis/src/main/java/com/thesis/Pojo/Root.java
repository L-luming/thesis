package com.thesis.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Root {
    private int id;
    //管理员账户
    private String account;
    //管理员密码
    private String password;

}
