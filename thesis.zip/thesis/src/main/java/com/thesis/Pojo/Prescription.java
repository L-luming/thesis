package com.thesis.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Prescription {
    private int id;
    //用户id
    private int userId;
    //医生姓名
    private String doctor;
    //药单详情码
    private int detail;
    //总金额
    private double sum;
    //开单时间
    private Date createTime;
}
