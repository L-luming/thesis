package com.thesis.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Worker {
    private int id;
    //工作人员姓名
    private String name;
    //工作人员性别
    private String sex;
    private int gender;
    //身份证号
    private String card;
    //职工号
    private String staffId;
    //密码
    private String password;
    //联系方式
    private String phone;
}
