package com.thesis.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OutputLog {
    private int id;
    //药品id
    private int drugId;
    //工作人员id
    private int workerId;
    //药单id
    private int prescriptionId;
    //出库数量
    private int number;
    //出库时间
    private Date outputTime;
}
