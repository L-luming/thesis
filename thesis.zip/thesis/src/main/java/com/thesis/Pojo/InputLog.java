package com.thesis.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class InputLog {
    private int id;
    //药品id
    private int drugId;
    //工作人员id
    private int workerId;
    //供货单id
    private int buyId;
    //入库数量
    private int number;
    //入库时间
    private Date createTime;
}
