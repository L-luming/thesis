package com.thesis.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class BuyDetail {
    private int id;
    //供货单id
    private int buyId;
    //供货单详情码
    private int detail;
    //药品id
    private int drugId;
    //数量
    private int number;
}
