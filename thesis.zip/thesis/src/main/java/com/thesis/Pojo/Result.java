package com.thesis.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Result<T> {
    private Integer code;
    private String message;
    private T data;

    public static <E> Result<E> success(E data) {
        return new Result<>(0, "success", data);
    }

    public static Result success() {
        return new Result<>(0, "success", null);
    }

    public static <E> Result<E> error(String message) {
        return new Result<>(1, message, null);
    }

    // 新增方法，用于传递自定义消息
    public static Result success(String message) {
        return new Result<>(0, message, null);
    }
    // 新增方法，用于传递自定义消息和数据
    public static <E> Result<E> success(E data, String message) {
        Result<E> result = new Result<>();
        result.setCode(0);
        result.setMessage(message);
        result.setData(data);
        return result;
    }
}
