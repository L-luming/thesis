package com.thesis.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
    private int id;
    //患者姓名
    private String name;
    //患者性别 男为1 女为0
    private String sex;
    private int gender;
    //患者身份证号
    private String card;
    //密码
    private String password;
    //联系方式
    private String phone;
}
