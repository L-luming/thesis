package com.thesis.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Drug {
    private int id;
    //药品名
    private String name;
    //药品规格
    private String specification;
    //药品类别
    private String category;
    //药品类型
    private String type;
    //药品单价
    private double price;
    //药品采购价格
    private double costPrice;
    //厂家
    private String vender;
    //生产日期
    private Date createTime;
    //限用日期
    private Date endTime;
    //库存信息
    private int store;
    //药房id
    private int pharmacyId;
}
