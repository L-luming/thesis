package com.thesis.Pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PrescriptionDetail {
    private int id;
    //药品id
    private int drugId;
    //药单id
    private int prescriptionId;
    //要单详情码
    private int prescriptionDetail;
    //出库数量
    private int number;

}
