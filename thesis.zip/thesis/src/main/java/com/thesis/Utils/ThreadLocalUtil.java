package com.thesis.Utils;

import java.util.Map;
/**
 * 工具类，用于操作线程本地变量。
 */
public class ThreadLocalUtil {

    private static final ThreadLocal<Map<String, Object>> THREAD_LOCAL = new ThreadLocal<>();

    /**
     * 设置线程本地变量。
     * @param map 要存储的 Map 对象
     */
    public static void set(Map<String, Object> map) {
        THREAD_LOCAL.set(map);
    }

    /**
     * 获取线程本地变量。
     * @return Map 线程本地变量
     */
    public static Map<String, Object> get() {
        return THREAD_LOCAL.get();
    }

    /**
     * 移除线程本地变量。
     */
    public static void remove() {
        THREAD_LOCAL.remove();
    }
}
//    private static final ThreadLocal THREAD_LOCAL = new ThreadLocal();
//    public static  <T> T get(){
//        return (T) THREAD_LOCAL.get();
//    }
//    public static void set(Object value){
//        THREAD_LOCAL.set(value);
//    }
//    public static void remove(){
//        THREAD_LOCAL.remove();
//    }
//}
