package com.thesis.Utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

import java.util.Date;
import java.util.Map;
/**
 * 工具类，用于生成和解析 JWT 令牌。
 */
public class JWTUtil {
    /**
     * 生成 JWT 令牌。
     * @param claims 令牌中的声明信息
     * @return String 生成的 JWT 令牌
     */
    public static String genToken(Map<String,Object> claims){
        return JWT.create()
                .withClaim("Ting",claims)
                .withExpiresAt(new Date(System.currentTimeMillis()*60*60))
                .sign(Algorithm.HMAC256("Ting"));// 使用 HMAC256 算法
    }
    /**
     * 解析 JWT 令牌。
     * @param token JWT 令牌
     * @return Map 解析后的声明信息
     */
    public static Map<String,Object> parseToken(String token){
        return JWT.require(Algorithm.HMAC256("Ting"))
                .build()
                .verify(token)
                .getClaim("Ting")
                .asMap();
    }

}
