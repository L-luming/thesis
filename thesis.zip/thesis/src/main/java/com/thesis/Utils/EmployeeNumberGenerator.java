package com.thesis.Utils;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * 工具类，用于生成员工编号。
 */
//员工编号生成器，用于生成员工编号
@Component
public class EmployeeNumberGenerator {
    private final String prefix;
    /**
     * 构造函数，初始化员工编号生成器。
     * @param prefix 编号前缀
     */
    public EmployeeNumberGenerator(@Value("${employee-number-prefix}") String prefix) {
        // 这里正确初始化了prefix
        this.prefix = prefix;
    }
    public String generateID(Integer id) {
        // 使用固定前缀和主键生成职工号
        return prefix + String.format("%04d", id);
    }
}
