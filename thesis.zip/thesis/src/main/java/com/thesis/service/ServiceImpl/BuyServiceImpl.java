package com.thesis.service.ServiceImpl;

import com.thesis.Pojo.Buy;
import com.thesis.Pojo.Result;
import com.thesis.mapper.BuyMapper;
import com.thesis.service.BuyService;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BuyServiceImpl implements BuyService {
    // 通过Spring的依赖注入获取BuyMapper实例
    @Resource
    private BuyMapper buyMapper;

    // 查询所有采购记录
    @Override
    public List<Buy> list() {
        return buyMapper.list();
    }

    // 根据供应商名称查询采购详情
    @Override
    public List<Buy> findByVender(String vender) {
        return buyMapper.findByVender(vender);
    }

    // 根据采购ID查询采购记录
    @Override
    public Buy findById(int id) {
        return buyMapper.findById(id);
    }

}
