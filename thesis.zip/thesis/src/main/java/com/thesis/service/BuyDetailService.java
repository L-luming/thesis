package com.thesis.service;

/**
 * 服务层接口，用于处理与供货单详情相关的业务逻辑。
 */
public interface BuyDetailService {
}
