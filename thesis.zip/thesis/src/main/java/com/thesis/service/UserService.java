package com.thesis.service;

import com.thesis.Pojo.User;

import java.util.List;

/**
 * 服务层接口，用于处理与用户相关的业务逻辑。
 */
public interface UserService {
    /**
     * 根据身份证号获取用户信息。
     * @param card 身份证号
     * @return User 用户信息
     */
    User findByCard(String card);

    /**
     * 验证用户密码。
     * @param card 身份证号
     * @param password 密码
     * @return boolean 密码是否匹配
     */
    boolean validatePassword(String card, String password);

    /**
     * 注册用户。
     * @param name 用户名
     * @param gender 性别
     * @param card 身份证号
     * @param saltedPassword 加密后的密码
     * @param phone 手机号
     */
    void register(String name, int gender, String card, String saltedPassword, String phone);

    /**
     * 删除用户。
     * @param card 身份证号
     */
    void delete(String card);

    /**
     * 更新用户密码。
     * @param newpwd 新密码
     * @param card 身份证号
     */
    void updatepassword(String newpwd);

    /**
     * 更新用户手机号。
     * @param phone 新手机号
     * @param card 身份证号
     */
    void update(String phone);

    /**
     * 获取所有用户。
     * @return List 包含所有用户
     */
    List<User> getAllUsers();

    User findById(int id);
}
