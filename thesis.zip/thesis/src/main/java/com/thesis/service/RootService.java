package com.thesis.service;

import com.thesis.Pojo.Root;

/**
 * 服务层接口，用于处理与管理员相关的业务逻辑。
 */
public interface RootService {
    /**
     * 验证管理员密码。
     * @param staffId 管理员账号
     * @param password 密码
     * @return boolean 密码是否匹配
     */
    boolean validatePassword(String staffId, String password);

    /**
     * 根据管理员账号获取管理员信息。
     * @param account 管理员账号
     * @return Root 管理员信息
     */
    Root findByAccount(String account);

}