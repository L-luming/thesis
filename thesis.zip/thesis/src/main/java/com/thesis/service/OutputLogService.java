package com.thesis.service;


import com.thesis.Pojo.OutputLog;

import java.util.List;
/**
 * 服务层接口，用于处理与出库日志相关的业务逻辑。
 */
public interface OutputLogService {
    /**
     * 获取所有出库日志。
     * @return List 包含所有出库日志
     */
    List<OutputLog> list();

    /**
     * 根据 ID 获取出库日志详情。
     * @param id 出库日志 ID
     * @return List 包含出库日志详情
     */
    List<OutputLog> detail(int id);
}
