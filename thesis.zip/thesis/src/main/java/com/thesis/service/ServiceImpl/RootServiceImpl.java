package com.thesis.service.ServiceImpl;

import com.thesis.Pojo.Root;
import com.thesis.mapper.RootMapper;
import com.thesis.service.RootService;
import jakarta.annotation.Resource;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

@Service
public class RootServiceImpl implements RootService {
    // 负责管理员数据操作
    @Resource
    private RootMapper rootMapper;

    @Override
    public boolean validatePassword(String account, String inputPassword) {
        // 验证管理员密码
        Root root = rootMapper.findByAccount(account);
        //用户为空代表没有该用户
        if (root == null) {
            return false;
        }
        // 使用 BCrypt 检查密码是否匹配
        return BCrypt.checkpw(inputPassword, root.getPassword());
    }
    // 根据管理员账户查询管理员信息
    @Override
    public Root findByAccount(String account) {
        return rootMapper.findByAccount(account);
    }


}
