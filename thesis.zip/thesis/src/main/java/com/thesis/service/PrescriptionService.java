package com.thesis.service;

import com.thesis.Pojo.Prescription;

import java.util.List;

/**
 * 服务层接口，用于处理与药单相关的业务逻辑。
 */
public interface PrescriptionService {
    /**
     * 获取所有药单。
     * @return List 包含所有药单
     */
    List<Prescription> list();

    /**
     * 获取当前用户的药单。
     * @return List 包含当前用户的药单
     */
    List<Prescription> userList();

    /**
     * 出库药品。
     * @param prescriptionId 药单 ID
     * @param workerId 工作人员 ID
     */
    void outputDrugs(int prescriptionId, int workerId);

    /**
     * 根据 ID 获取药单及其详情。
     * @param id 药单 ID
     * @return Prescription 包含药单及其详情
     */
    Prescription getById(int id);

}