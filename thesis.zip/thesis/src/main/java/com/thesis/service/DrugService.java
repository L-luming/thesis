package com.thesis.service;

import com.thesis.Pojo.Drug;

import java.util.List;

/**
 * 服务层接口，用于处理与药品相关的业务逻辑。
 */
public interface DrugService {
    /**
     * 获取所有药品。
     * @return List 包含所有药品
     */
    List<Drug> list();

    /**
     * 根据名称获取药品详情。
     * @param name 药品名称
     * @return List 包含药品详情
     */
    List<Drug> detail(String name);

    List<Drug> findById(int id);
}