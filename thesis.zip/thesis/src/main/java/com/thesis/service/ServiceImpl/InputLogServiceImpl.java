package com.thesis.service.ServiceImpl;

import com.thesis.Pojo.BuyDetail;
import com.thesis.Pojo.Drug;
import com.thesis.Pojo.InputLog;
import com.thesis.mapper.BuyDetailMapper;
import com.thesis.mapper.DrugMapper;
import com.thesis.mapper.InputLogMapper;
import com.thesis.service.InputLogService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class InputLogServiceImpl implements InputLogService {
    @Resource
    private BuyDetailMapper buyDetailMapper; // 负责采购详情的数据操作

    @Resource
    private InputLogMapper inputLogMapper;// 负责入库记录的数据操作

    @Resource
    private DrugMapper drugMapper;// 负责药品的数据操作

    // 根据采购订单ID查询采购详情
    @Override
    public void inputDrugs(int buyDetailId, int workerId) {
        // 先查询供货详情
        List<BuyDetail> details = buyDetailMapper.getDetail(buyDetailId);
        if (details.isEmpty()) {
            throw new RuntimeException("供货单无详情信息");
        }
        for (BuyDetail detail : details) {
            // 获取药品ID
            Integer drugId = detail.getDrugId();
            if (drugId == null) {
                throw new RuntimeException("药品 ID: " + drugId + " 不存在，出库失败");
            }
            // 获取采购数量
            int inputNumber = detail.getNumber();

            // 先插入入库记录（不包含工作人员id和入库时间）
            InputLog inputlog = new InputLog();
            inputlog.setDrugId(drugId);
            inputlog.setBuyId(buyDetailId);
            inputlog.setNumber(inputNumber);
            inputLogMapper.insertInputLog(inputlog);

            // 更新药品库存
            Drug drug = drugMapper.getDrugById(drugId);
            drug.setStore(drug.getStore() + inputNumber);
            drugMapper.updateDrugStore(drug);

            // 更新入库记录，填入工作人员id和入库时间
            inputlog.setWorkerId(workerId);
            inputlog.setCreateTime(new Date());
            inputLogMapper.updateInputLog(inputlog);
        }
    }

    // 查询所有入库记录
    @Override
    public List<InputLog> list() {
        return inputLogMapper.list();
    }

    // 查询特定ID的入库记录
    @Override
    public InputLog detail(int id) {
        return inputLogMapper.detail(id);
    }
}
