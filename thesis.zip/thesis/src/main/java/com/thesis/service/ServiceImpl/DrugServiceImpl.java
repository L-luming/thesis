package com.thesis.service.ServiceImpl;

import com.thesis.Pojo.Drug;
import com.thesis.mapper.DrugMapper;
import com.thesis.service.DrugService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DrugServiceImpl implements DrugService {
    // 负责药品数据操作
    @Resource
    private DrugMapper drugMapper;

    // 查询所有药品
    @Override
    public List<Drug> list() {
        return drugMapper.list();
    }

    // 根据药品名查找药品，并返回药品详情
    @Override
    public List<Drug> detail(String name) {
        int id = drugMapper.findByName(name);
        return drugMapper.detail(id);
    }

    @Override
    public List<Drug> findById(int id) {
        return drugMapper.findById(id);
    }
}
