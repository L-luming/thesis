package com.thesis.service;

import com.thesis.Pojo.Worker;

import java.util.List;
/**
 * 服务层接口，用于处理与工作人员相关的业务逻辑。
 */
public interface WorkerService {
    /**
     * 根据身份证号获取工作人员信息。
     * @param card 身份证号
     * @return Worker 工作人员信息
     */
    Worker findByCard(String card);

    /**
     * 添加工作人员。
     */
    void add(Worker worker);

    /**
     * 验证工作人员密码。
     * @param staffId 工作人员账号
     * @param password 密码
     * @return boolean 密码是否匹配
     */
    boolean validatePassword(String staffId, String password);

    /**
     * 根据工作人员账号获取工作人员信息。
     * @param staffId 工作人员账号
     * @return Worker 工作人员信息
     */
    Worker findByStaffId(String staffId);

    /**
     * 更新工作人员手机号。
     * @param phone 新手机号
     * @param staffId 工作人员账号
     */
    void update(String phone);

    /**
     * 更新工作人员密码。
     * @param newpwd 新密码
     * @param staffId 工作人员账号
     */
    void updatepassword(String newpwd);

    /**
     * 删除工作人员。
     * @param staffId 工作人员账号
     */
    void delete(String staffId);

    /**
     * 获取所有工作人员。
     * @return List 包含所有工作人员
     */
    List<Worker> getAllWorkers();

    void updateStaffId(String staffId, Integer id);
}