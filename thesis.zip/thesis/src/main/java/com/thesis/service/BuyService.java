package com.thesis.service;

import com.thesis.Pojo.Buy;

import java.util.List;
/**
 * 服务层接口，用于处理与供货单相关的业务逻辑。
 */
public interface BuyService {

    /**
     * 获取所有供货单。
     * @return List 包含所有供货单
     */
    List<Buy> list();

    /**
     * 根据供货商获取供货单详情。
     * @param vender 供货商名称
     * @return List 包含供货单详情
     */
    List<Buy> findByVender(String vender);

    /**
     * 根据 ID 获取供货单。
     * @param id 供货单 ID
     * @return List 包含供货单
     */
    Buy findById(int id);

}
