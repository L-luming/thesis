package com.thesis.service.ServiceImpl;

import com.thesis.Pojo.User;
import com.thesis.Utils.ThreadLocalUtil;
import com.thesis.mapper.UserMapper;
import com.thesis.service.UserService;
import jakarta.annotation.Resource;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class UserServiceImpl implements UserService {
    // 负责用户数据操作
    @Resource
    private UserMapper userMapper;

    //根据身份证号查找用户是否存在
    @Override
    public User findByCard(String card) {
        return userMapper.findByCard(card);
    }

    //核对盐值是否一致 判断密码是否正确
    public boolean validatePassword(String card, String inputPassword) {

        User user = userMapper.findByCard(card);
        //用户为空代表没有该用户
        if (user == null) {
            return false;
        }
        // 使用 BCrypt 检查密码是否匹配
        return BCrypt.checkpw(inputPassword, user.getPassword());
    }
    // 注册用户
    @Override
    public void register(String name, int gender, String card, String saltedPassword, String phone) {
        userMapper.register(name, gender, card, saltedPassword, phone);
    }
    // 删除用户
    @Override
    public void delete(String card) {
        userMapper.delete(card);
    }
    // 更新用户密码
    @Override
    public void updatepassword(String newpwd) {
        Map<String, Object> map = ThreadLocalUtil.get();
        String card = (String) map.get("card");
        userMapper.updatepassword(newpwd, card);
    }
    // 更新用户联系方式
    @Override
    public void update(String phone) {
        Map<String, Object> map = ThreadLocalUtil.get();
        String card = (String) map.get("card");
        userMapper.update(phone, card);
    }
    // 查询所有用户
    @Override
    public List<User> getAllUsers() {
        return userMapper.getAllUsers();
    }
    //根据id返回用户信息
    @Override
    public User findById(int id) {
        return userMapper.findById(id);
    }
}
