package com.thesis.service.ServiceImpl;

import com.thesis.Pojo.OutputLog;
import com.thesis.mapper.OutputLogMapper;
import com.thesis.service.OutputLogService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OutputLogServiceImpl implements OutputLogService {
    // 负责出库记录的数据操作
    @Resource
    private OutputLogMapper outputLogMapper;

    // 查询所有出库记录
    @Override
    public List<OutputLog> list() {
        return outputLogMapper.list();
    }

    // 查询特定ID的出库记录
    @Override
    public List<OutputLog> detail(int id) {
        return outputLogMapper.detail(id);
    }
}
