package com.thesis.service.ServiceImpl;

import com.thesis.Pojo.User;
import com.thesis.Pojo.Worker;
import com.thesis.Utils.ThreadLocalUtil;
import com.thesis.mapper.WorkerMapper;
import com.thesis.service.WorkerService;
import jakarta.annotation.Resource;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class WorkerServiceIml implements WorkerService {
    // 负责员工数据操作
    @Resource
    private WorkerMapper workerMapper;

    // 根据身份证号查找员工
    @Override
    public Worker findByCard(String card) {
        return workerMapper.findByCard(card);
    }

    // 添加员工
    @Override
    public void add(Worker worker) {
        workerMapper.add(worker);
    }

    @Override
    //核对盐值是否一致 判断密码是否正确
    public boolean validatePassword(String staffId, String inputPassword) {
        Worker worker = workerMapper.findByStaffId(staffId);
        //用户为空代表没有该用户
        if (worker == null) {
            return false;
        }
        // 使用 BCrypt 检查密码是否匹配
        return BCrypt.checkpw(inputPassword, worker.getPassword());
    }

    // 根据员工ID查询员工信息
    @Override
    public Worker findByStaffId(String staffId) {
        return workerMapper.findByStaffId(staffId);
    }

    // 更新员工联系方式
    @Override
    public void update(String phone) {
        Map<String, Object> map = ThreadLocalUtil.get();
        String staffId = (String) map.get("staffId");
        workerMapper.update(phone, staffId);
    }

    // 更新员工密码
    @Override
    public void updatepassword(String newpwd) {
        Map<String, Object> map = ThreadLocalUtil.get();
        String staffId = (String) map.get("staffId");
        workerMapper.updatepassword(newpwd, staffId);

    }

    // 删除员工
    @Override
    public void delete(String staffId) {
        workerMapper.delete(staffId);

    }

    // 查询所有员工
    @Override
    public List<Worker> getAllWorkers() {
        return workerMapper.getAllWorkers();
    }

    @Override
    public void updateStaffId(String staffId, Integer id) {
        workerMapper.updateStaffId(staffId, id);
    }
}
