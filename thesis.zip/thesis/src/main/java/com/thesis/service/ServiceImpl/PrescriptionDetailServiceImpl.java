package com.thesis.service.ServiceImpl;

import com.thesis.service.PrescriptionDetailService;
import org.springframework.stereotype.Service;

@Service
public class PrescriptionDetailServiceImpl implements PrescriptionDetailService {

}
