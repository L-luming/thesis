package com.thesis.service.ServiceImpl;

import com.thesis.service.BuyDetailService;
import org.springframework.stereotype.Service;
// 使用 @Service 注解表明这是一个服务实现类
@Service
public class BuyDetailServiceImpl implements BuyDetailService {

}
