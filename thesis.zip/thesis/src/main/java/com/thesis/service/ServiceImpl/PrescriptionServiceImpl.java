package com.thesis.service.ServiceImpl;

import com.thesis.Pojo.*;
import com.thesis.Utils.ThreadLocalUtil;
import com.thesis.mapper.DrugMapper;
import com.thesis.mapper.OutputLogMapper;
import com.thesis.mapper.PrescriptionDetailMapper;
import com.thesis.mapper.PrescriptionMapper;
import com.thesis.service.PrescriptionService;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Service
public class PrescriptionServiceImpl implements PrescriptionService {
    // 负责药单的数据操作
    @Resource
    private PrescriptionMapper prescriptionMapper;
    // 负责药单详情的数据操作
    @Resource
    private PrescriptionDetailMapper prescriptionDetailMapper;
    // 负责药品的数据操作
    @Resource
    private DrugMapper drugMapper;
    // 负责出库记录的数据操作
    @Resource
    private OutputLogMapper outputLogMapper;


    // 查询所有药单
    @Override
    public List<Prescription> list() {
        return prescriptionMapper.list();
    }


    // 获取当前用户ID并查询其药单
    @Override
    public List<Prescription> userList() {
        //获取用户id 查询本人药单
        Map<String, Object> map = ThreadLocalUtil.get();
        Integer id = (Integer) map.get("id");
        return prescriptionMapper.userList(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class) // 事务注解，确保数据一致性
    public void outputDrugs(int prescriptionId, int workerId) {
        // 根据药单ID查询药单详情
        List<PrescriptionDetail> details = prescriptionDetailMapper.getDetailsByPrescriptionId(prescriptionId);
        if (details.isEmpty()) {
            throw new RuntimeException("药单无详情信息");
        }
        for (PrescriptionDetail detail : details) {
            // 获取药品ID
            int drugId = detail.getDrugId();
            // 获取出库数量
            int outputNumber = detail.getNumber();
            // 加锁查询药品库存
            Drug drug = drugMapper.getDrugWithLock(drugId);
            // 检查药品是否存在
            if (drug == null) {
                throw new RuntimeException("药品 ID: " + drugId + " 不存在，出库失败");
            }

            if (drug.getStore() < outputNumber) {
                // 库存不足，抛出异常并回滚事务
                throw new RuntimeException("药品 ID: " + drugId + " 库存不足，出库失败");
            }


            // 先插入出库记录（不包含工作人员id和出库时间）
            OutputLog outputLog = new OutputLog();
            outputLog.setDrugId(drugId);
            outputLog.setPrescriptionId(prescriptionId);
            outputLog.setNumber(outputNumber);
            outputLogMapper.insertOutputLog(outputLog);

            // 更新药品库存
            drug.setStore(drug.getStore() - outputNumber);
            drugMapper.updateDrugStore(drug);

            // 更新出库记录，填入工作人员id和出库时间
            outputLog.setWorkerId(workerId);
            outputLog.setOutputTime(new Date());
            outputLogMapper.updateOutputLog(outputLog);
        }

    }

    // 根据药单ID获取详细信息
    @Override
    public Prescription getById(int id) {
        return prescriptionMapper.getById(id);
    }


}
