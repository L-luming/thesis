package com.thesis.service;


import com.thesis.Pojo.InputLog;

import java.util.List;
/**
 * 服务层接口，用于处理与入库日志相关的业务逻辑。
 */
public interface InputLogService {
    /**
     * 入库药品。
     *
     * @param buyId    供货单 ID
     * @param workerId 工作人员 ID
     */
    void inputDrugs(int buyId, int workerId);

    /**
     * 获取所有入库日志。
     *
     * @return List 包含所有入库日志
     */
    List<InputLog> list();

    /**
     * 根据 ID 获取入库日志详情。
     *
     * @param id 入库日志 ID
     * @return List 包含入库日志详情
     */
    InputLog detail(int id);
}