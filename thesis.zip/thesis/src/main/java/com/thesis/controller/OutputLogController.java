package com.thesis.controller;

import com.thesis.Pojo.OutputLog;
import com.thesis.Pojo.Result;
import com.thesis.service.OutputLogService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
/**
 * 控制器，用于处理与出库日志相关的请求。
 */
@RestController
@RequestMapping("/output")
public class OutputLogController {
    @Resource
    private OutputLogService outputLogService;
    /**
     * 获取所有出库日志。
     * @return Result 包含出库日志列表
     */
    @GetMapping("/list")
    public Result list() {
        List<OutputLog> list = outputLogService.list();
        return Result.success(list);
    }
    /**
     * 根据 ID 获取出库日志详情。
     * @param id 出库日志 ID
     * @return Result 包含出库日志详情列表
     */
    @GetMapping("/detail/{id}")
    public Result detail(@PathVariable int id) {
        List<OutputLog> list = outputLogService.detail(id);
        return Result.success(list);
    }
}
