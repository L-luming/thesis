package com.thesis.controller;

import com.thesis.Pojo.Buy;
import com.thesis.Pojo.Drug;
import com.thesis.Pojo.Result;
import com.thesis.service.DrugService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;
/**
 * 控制器，用于处理与药品相关的请求。
 */
@RestController
@RequestMapping("/drug")
public class DrugController {
    @Resource
    private DrugService drugService;
    /**
     * 获取所有药品。
     * @return Result 包含药品列表
     */
    @GetMapping("/list")
    public Result list(){
        List<Drug> list =  drugService.list();
        return Result.success(list);
    }
    /**
     * 根据名称获取药品详情。
     * @param name 药品名称
     * @return Result 包含药品详情列表
     */
    @GetMapping("/detail")
    public Result detail(@RequestParam String name){
        List<Drug> list =  drugService.detail(name);
        return Result.success(list);
    }
    //根据id获取药品详情
    @GetMapping("/detail/{id}")
    public List<Drug> detail(@PathVariable int id){
        return drugService.findById(id);
    }
}
