package com.thesis.controller;

import com.thesis.Pojo.Prescription;
import com.thesis.Utils.ThreadLocalUtil;
import com.thesis.service.PrescriptionService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
/**
 * 控制器，用于处理与药单相关的请求。
 */
@RestController
@RequestMapping("/prescription")
public class PrescriptionController {
    // 通过 Spring 的依赖注入获取服务层实例
    @Resource
    private PrescriptionService prescriptionService;
    /**
     * 获取所有药单。
     * @return List 包含所有药单
     */
    @GetMapping("/list")
    public List<Prescription> list() {
        return prescriptionService.list();
    }
    /**
     * 获取当前用户的药单。
     * @return List 包含当前用户的药单
     */
    @GetMapping("/user")
    public List<Prescription> user() {
        return prescriptionService.userList();
    }
    /**
     * 出库药品。
     * @param requestBody 请求体 只传输药单id
     * @return String 出库结果
     */
    @PostMapping("/output")
    public String outputDrugs(@RequestBody Map<String, Object> requestBody) {
        // 获取当前线程的用户信息
        Map<String,Object> map = ThreadLocalUtil.get();
        // 获取工作人员 ID
        int workerId = (Integer) map.get("id");
        // 获取药单 ID
        Integer prescriptionId = (Integer)requestBody.get("id") ;
        try {
            prescriptionService.outputDrugs(prescriptionId,workerId);
            return "出库成功";
        } catch (Exception e) {
            return "出库失败: " + e.getMessage();
        }
    }
    /**
     * 根据 ID 获取药单及其详情。
     * @param id 药单 ID
     * @return Prescription 包含药单及其详情
     */
    @GetMapping("/detail/{id}")
    public Prescription getById(@PathVariable int id) {
        return prescriptionService.getById(id);
    }
}
