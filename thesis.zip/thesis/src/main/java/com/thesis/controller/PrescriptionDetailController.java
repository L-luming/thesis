package com.thesis.controller;

import com.thesis.service.PrescriptionService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.RestController;
/**
 * 控制器，用于处理与药单详情相关的请求。
 */
@RestController
public class PrescriptionDetailController {
    @Resource
    private PrescriptionService prescriptionService;
}
