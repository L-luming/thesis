package com.thesis.controller;

import com.thesis.Pojo.InputLog;
import com.thesis.Pojo.Result;
import com.thesis.Utils.ThreadLocalUtil;
import com.thesis.service.InputLogService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
/**
 * 控制器，用于处理与入库日志相关的请求。
 */
@RestController
@RequestMapping("/input")
public class InputLogController {
    // 通过 Spring 的依赖注入获取服务层实例
    @Resource
    private InputLogService inputLogService;
    /**
     * 入库药品。
     * @param requestBody 请求体
     * @return String 入库结果
     */
    @PostMapping("/store")
    public String inputDrugs(@RequestBody  Map<String, Object> requestBody) {
        try {
            // 获取当前线程的用户信息
            Map<String,Object> map = ThreadLocalUtil.get();
            // 获取工作人员 ID
            int workerId = (Integer) map.get("id");
            // 获取药单 ID
            Integer buyId = (Integer)requestBody.get("id") ;
            // 调用服务层的入库方法
            inputLogService.inputDrugs(buyId,workerId );
            return "入库成功";
        } catch (Exception e) {
            // 捕获异常并返回错误信息
            return "入库失败: " + e.getMessage();
        }
    }
    /**
     * 获取所有入库日志。
     * @return Result 包含入库日志列表
     */
    @GetMapping("/list")
    public Result list() {
        List<InputLog> list = inputLogService.list();
        return Result.success(list);
    }
    /**
     * 根据 ID 获取入库日志详情。
     * @param id 入库日志 ID
     * @return Result 包含入库日志详情列表
     */
    @GetMapping("/detail/{id}")
    public InputLog detail(@PathVariable int id) {
        return inputLogService.detail(id);
    }
}
