package com.thesis.controller;

import com.thesis.Pojo.Result;
import com.thesis.Pojo.Worker;
import com.thesis.Utils.EmployeeNumberGenerator;
import com.thesis.Utils.JWTUtil;
import com.thesis.Utils.ThreadLocalUtil;
import com.thesis.service.WorkerService;
import jakarta.annotation.Resource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
/**
 * 控制器，用于处理与工作人员相关的请求。
 */
@RestController
@RequestMapping("/worker")
public class WorkerController {
    @Resource
    private WorkerService workerService;
    @Value("${initial-password}")
    private String initialPassword;
    @Resource
    private EmployeeNumberGenerator employeeNumberGenerator; // 注入 EmployeeNumberGenerator

    /**
     * 添加工作人员。
     * @param name 姓名
     * @param sex 性别
     * @param card 身份证号
     * @param phone 手机号
     * @return Result 添加结果
     */
    @PostMapping("/add") //添加工作人员功能 管理员手动增加工作人员
    public Result register(String name, String sex,String card,String phone) {
        // 定义一个worker类型的变量进行接收根据card查询的worker数据
        Worker worker = workerService.findByCard(card);
        if (worker == null) {
            // 如果没有查询到则对用户的密码进行加盐
            // 使用 bcrypt 加盐加密
            String password = initialPassword;
            String saltedPassword = BCrypt.hashpw(password, BCrypt.gensalt(12));
            // 检查身份证号和手机号的长度
            String idCardPattern = "(^\\d{15}$)|(\\d{17}([0-9]|X)$)";
            if (!card.matches(idCardPattern)) {
                return Result.error("身份证号格式错误");
            }
            String phonePattern = "^1[3-9]\\d{9}$";
            if (!phone.matches(phonePattern)) {
                return Result.error("手机号格式错误");
            }
            // 将性别字符串转换为数值
            int gender = "男".equals(sex) ? 1 : 0;
            // 创建新的 Worker 对象
            Worker newWorker = new Worker();
            newWorker.setName(name);
            newWorker.setSex(String.valueOf(gender));
            newWorker.setCard(card);
            newWorker.setPassword(saltedPassword);
            newWorker.setPhone(phone);
            // 插入新工作人员
            workerService.add(newWorker);
            // 获取数据库生成的主键 id
            Integer id = newWorker.getId();
            if (id != null) {
                // 根据主键生成职工号
                String staffId = employeeNumberGenerator.generateID(id);
                // 更新职工号到数据库
                workerService.updateStaffId(staffId, id);
            }
            return Result.success("添加成功");
        } else {
            return Result.error("员工已存在");
        }
    }

    /**
     * 获取工作人员详细信息。
     * @return Result 包含工作人员详细信息
     */
    @GetMapping("/workerInfo")
    public Result getWorkerInfo() {
        //获取当前登录用户的身份证号
        Map<String,Object> map = ThreadLocalUtil.get();
        if (map == null || !map.containsKey("staffId")) {
            return Result.error("未获取到用户信息");
        }

        String staffId = (String) map.get("staffId");
        //获取用户详细信息
        Worker worker = workerService.findByStaffId(staffId);
        if (worker == null) {
            return Result.error("未找到用户信息");
        }
        return Result.success(worker);
    }
    /**
     * 更新工作人员信息。
     * @param phone 新的手机号
     * @return Result 更新结果
     */
    @PutMapping("/update")   //更新用户信息
    public Result updateUserInfo(@RequestBody String phone) {
        //获取当前登录用户的身份证号
        Map<String,Object> map = ThreadLocalUtil.get();
        //获取用户信息
        String account = (String) map.get("card");
        Worker worker  = workerService.findByCard(account);
        // 去除手机号中的空格和其他特殊字符
        phone = phone.replace(" ", "").replaceAll("[^\\d]", "");
        //校验手机号
        String phonePattern = "^1[3-9]\\d{9}$";
        if (!phone.matches(phonePattern)) {
            return Result.error("手机号格式错误");
        }
        workerService.update(phone);
        //只做判定长度 暂不考虑手机号重复的问题
        return Result.success("修改成功！");
    }
    /**
     * 修改密码。
     * @param map 包含旧密码、新密码和确认密码的 Map
     * @return Result 修改结果
     */
    @PatchMapping("/updatepassword")//修改密码
    public Result updatepassword(@RequestBody Map<String,String> map/*,@RequestHeader("Authorization") String token*/) {
        //从请求体中获取密码
        String oldPassword = map.get("oldpassword");
        String newPassword = map.get("newpassword");
        String rePassword = map.get("repassword");
        // 检查参数是否为空
        if(!StringUtils.hasLength(oldPassword)||!StringUtils.hasLength(newPassword)||!StringUtils.hasLength(rePassword)){
            return Result.error("缺少必要的参数");
        }
        // 从 ThreadLocal 中获取当前用户信息
        Map<String,Object> TT = ThreadLocalUtil.get();
        String staffId =(String) TT.get("staffId");
        // 查询当前用户
        Worker worker = workerService.findByStaffId(staffId);
        // 验证旧密码是否正确
        if (!BCrypt.checkpw(oldPassword, worker.getPassword())) {
            return Result.error("原密码不一致");
        }
        // 验证两次输入的新密码是否一致
        if (!newPassword.equals(rePassword)) {
            return Result.error("两次密码不一致");
        }
        // 对新密码进行 BCrypt 加密
        //BCrypt.gensalt() 生成盐值 ：gensalt() 方法生成一个随机的盐值（Salt）。盐值是一个随机字符串，用于增强密码的安全性，防止彩虹表攻击。
        String newpwd = BCrypt.hashpw(newPassword,BCrypt.gensalt());
        // 更新密码
        workerService.updatepassword(newpwd);
        return Result.success();
    }
    /**
     * 删除工作人员。
     * @param staffId 工作人员账号
     * @return Result 删除结果
     */
    @DeleteMapping("/delete") //用户注销功能
    public Result delete(@RequestBody Map<String, String> request){
        String staffId = request.get("staffId");
        // 或者使用正则去除非数字字符
        staffId = staffId.replaceAll("\"", "");
        Worker worker = workerService.findByStaffId(staffId);
        if (worker == null) {
            return  Result.error("该用户不存在！");
        }
        workerService.delete(staffId);
        return Result.success("删除成功");
    }

    /**
     * 工作人员登录。
     * @param staffId 工作人员账号
     * @param password 密码
     * @return Result 登录结果
     */
    /*@PostMapping("/login")     //登录功能
    public Result login(@RequestParam String staffId,@RequestParam String password) {
        Worker worker = workerService.findByStaffId(staffId); // 获取用户对象
        if (worker == null) {
            return Result.error("用户不存在");
        }
        // 使用 bcrypt 验证用户和密码
        boolean isValid = workerService.validatePassword(staffId, password);
        if (!isValid) {
            return Result.error("用户名或密码错误，请核对后重新输入");
        }
        // 生成 JWT token
        Map<String, Object> claims = new HashMap<>();
        *//* 用户的 ID *//*
        claims.put("id", worker.getId());
        *//* 用户的账号 *//*
        claims.put("staffId", worker.getStaffId());
        claims.put("userType", "worker"); // 判断用户是否为管理员
        //获取token
        String token = JWTUtil.genToken(claims);
        // 判断是否使用初始密码
        boolean isInitialPassword = BCrypt.checkpw("123456", worker.getPassword());
        if (isInitialPassword) {
            return Result.success(token,"请尽快修改初始密码");
        } else {
            return Result.success(token);
        }
    }*/
}
