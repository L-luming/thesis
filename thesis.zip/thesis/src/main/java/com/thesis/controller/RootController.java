package com.thesis.controller;

import com.thesis.Pojo.*;
import com.thesis.service.*;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;
/**
 * 控制器，用于处理与管理员相关的请求。
 */
@RestController
@RequestMapping("/root")
public class RootController {
    @Resource
    private UserService userService;
    @Resource
    private WorkerService workerService;
    @Resource
    private PrescriptionService prescriptionService;
    @Resource
    private BuyService buyService;
    /**
     * 获取所有用户信息。
     * @return Result 包含用户列表
     */
    @GetMapping("/users") // 管理员查看用户信息
    public Result getAllUsers() {
        List<User> users = userService.getAllUsers();
        return Result.success(users, "用户信息获取成功");
    }
    /**
     * 获取所有工作人员信息。
     * @return Result 包含工作人员列表
     */
    @GetMapping("/workers") // 管理员查看工作人员信息
    public Result getAllWorkers() {
        List<Worker> workers = workerService.getAllWorkers();
        return Result.success(workers, "工作人员信息获取成功");
    }
    /**
     * 获取所有药单信息。
     * @return Result 包含药单列表
     */
    @GetMapping("/prescription") // 查看药单信息
    public Result getAllprescription() {
        List<Prescription> prescription = prescriptionService.list();
        return Result.success(prescription, "药单信息获取成功");
    }
    /**
     * 获取所有药单信息。
     * @return Result 包含药单列表
     */
    @GetMapping("/prescription/{id}") // 查看药单详细信息
    public Result getPrescriptionDetail(@PathVariable int id) {
        Prescription prescription =  prescriptionService.getById(id);
        return Result.success(prescription, "药单详情获取成功");
    }
    /**
     * 获取所有供货单信息。
     * @return Result 包含药单列表
     */
    @GetMapping("/buy") // 查看供货单信息
    public Result getAllbuy() {
        List<Buy> buy = buyService.list();
        return Result.success(buy, "供货单信息获取成功");
    }

     /** 获取所有供货单信息。
      * @return Result 根据id返回供货单详细数据
     */
    @GetMapping("/buy/{id}") // 查看供货单详细信息
    public Result getBuyDetail(@PathVariable int id) {
        Buy buy = buyService.findById(id);
        return Result.success(buy, "供货单详情获取成功");
    }
    /** 删除某一用户。
     * @return Result 根据id删除用户数据
     */
    @DeleteMapping("/user/{id}") // 查看供货单详细信息
    public Result delete(@PathVariable int id) {
        User user = userService.findById(id);
        String card =  user.getCard();
        userService.delete(card);
        return Result.success("删除成功");
    }
    /**
     * 管理员登录。
     * @param staffId 管理员账号
     * @param password 密码
     * @return Result 登录结果
     */
    /*@PostMapping("/login")     //登录功能
    public Result login(String staffId, String password) {
        Root root = rootService.findByStaffId(staffId); // 获取用户对象
        if (root == null) {
            return Result.error("用户不存在");
        }
        // 使用 bcrypt 验证用户和密码
        boolean isValid = rootService.validatePassword(staffId, password);
        if (!isValid) {
            return Result.error("用户名或密码错误，请核对后重新输入");
        }
        // 生成 JWT token
        Map<String, Object> claims = new HashMap<>();
        *//* 用户的 ID *//*
        claims.put("id", root.getId());
        *//* 用户的账号 *//*
        claims.put("staffId", root.getStaffId());
        //获取token
        String token = JWTUtil.genToken(claims);
        // 将用户信息存储到 ThreadLocal 中
        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("card", root.getStaffId());
        ThreadLocalUtil.set(userInfo);
        return Result.success(token);
    }*/
}
