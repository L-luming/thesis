package com.thesis.controller;

import com.thesis.Pojo.Result;
import com.thesis.Pojo.User;
import com.thesis.Utils.JWTUtil;
import com.thesis.Utils.ThreadLocalUtil;
import com.thesis.service.UserService;
import jakarta.annotation.Resource;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
/**
 * 控制器，用于处理与用户相关的请求。
 */
@CrossOrigin
@RestController
@RequestMapping("/user")
public class UserController {
    //依赖注入
    @Resource
    private UserService userService;
    /**
     * 用户注册。
     * @param name 用户名
     * @param sex 性别
     * @param card 身份证号
     * @param password 密码
     * @param phone 手机号
     * @return Result 注册结果
     */
    @PostMapping("/register") //注册功能
    public Result register(String name, String sex, String card, String password, String phone) {
        // 定义一个user类型的变量进行接收根据card查询的user数据
        User user = userService.findByCard(card);
        if (user == null) {
            // 如果没有查询到则对用户的密码进行加盐
            // 使用 bcrypt 加盐加密
            String saltedPassword = BCrypt.hashpw(password, BCrypt.gensalt(12));
            // 检查身份证号
            String idCardPattern = "(^\\d{15}$)|(\\d{17}([0-9]|X)$)";
            if (!card.matches(idCardPattern)) {
                return Result.error("身份证号格式错误");
            }
            //校验手机号
            String phonePattern = "^1[3-9]\\d{9}$";
            if (!phone.matches(phonePattern)) {
                return Result.error("手机号格式错误");
            }
            // 将性别字符串转换为数值
            int gender = "男".equals(sex) ? 1 : 0;

            // 调用 userService 注册用户，传入加密后的密码和性别数值
            userService.register(name, gender, card, saltedPassword, phone);

            return Result.success("注册成功");
        } else {
            return Result.error("用户名已存在");
        }
    }
    /**
     * 获取用户详细信息。
     * @return Result 包含用户详细信息
     */
    @GetMapping("/userInfo")    //获取用户详细信息
    public Result<User> getUserInfo() {
        //获取当前登录用户的身份证号
        Map<String,Object> map = ThreadLocalUtil.get();
        if (map == null || !map.containsKey("card")) {
            return Result.error("未获取到用户信息");
        }
        String inform  = (String) map.get("card");
        //获取用户详细信息
        User user = userService.findByCard(inform);
        if (user == null) {
            return Result.error("未找到用户信息");
        }
        return Result.success(user);
    }
    /**
     * 更新用户信息。
     * @param phone 新的手机号
     * @return Result 更新结果
     */
    @PutMapping("/update")   //更新用户信息
    public Result updateUserInfo(@RequestBody String phone) {
        //获取当前登录用户的身份证号
        Map<String,Object> map = ThreadLocalUtil.get();
        //获取用户信息
        String account = (String) map.get("card");
        User user  = userService.findByCard(account);
        //校验手机号
        // 去除手机号中的空格和其他特殊字符
        phone = phone.replace(" ", "").replaceAll("[^\\d]", "");
        //^：表示字符串的开始。
        //1：手机号必须以 1 开头。
        //[3-9]：手机号的第二位必须是 3 到 9 之间的数字。
        //\\d{9}：表示后面必须有连续的 9 位数字。
        //$：表示字符串的结束。
        String phonePattern = "^1[3-9]\\d{9}$";
        if (!phone.matches(phonePattern)) {
            return Result.error("手机号格式错误");
        }
        userService.update(phone);
        //只做判定长度 暂不考虑手机号重复的问题
        return Result.success("修改成功！");
    }
    /**
     * 修改密码。
     * @param map 包含旧密码、新密码和确认密码的 Map
     * @return Result 修改结果
     */
    @PatchMapping("/updatepassword")//修改密码
    public Result updatepassword(@RequestBody Map<String,String> map/*,@RequestHeader("Authorization") String token*/) {
        //从请求体中获取密码
        String oldPassword = map.get("oldpassword");
        String newPassword = map.get("newpassword");
        String rePassword = map.get("repassword");
        // 检查参数是否为空
        if(!StringUtils.hasLength(oldPassword)||!StringUtils.hasLength(newPassword)||!StringUtils.hasLength(rePassword)){
            return Result.error("缺少必要的参数");
        }
        // 从 ThreadLocal 中获取当前用户信息
        Map<String,Object> TT = ThreadLocalUtil.get();
        String card =(String) TT.get("card");
        // 查询当前用户
        User uu = userService.findByCard(card);
        // 验证旧密码是否正确
        if (!BCrypt.checkpw(oldPassword, uu.getPassword())) {
            return Result.error("原密码不一致");
        }
        // 验证两次输入的新密码是否一致
        if (!newPassword.equals(rePassword)) {
            return Result.error("两次密码不一致");
        }
        // 对新密码进行 BCrypt 加密
        //BCrypt.gensalt() 生成盐值 ：gensalt() 方法生成一个随机的盐值（Salt）。盐值是一个随机字符串，用于增强密码的安全性，防止彩虹表攻击。
        String newpwd = BCrypt.hashpw(newPassword,BCrypt.gensalt());
        // 更新密码
        userService.updatepassword(newpwd);
        return Result.success();
    }
    /**
     * 用户注销。
     * @return Result 注销结果
     */
    @DeleteMapping("/delete") //用户注销功能
    public Result delete(){
        /*
        * 考虑到实现的界面是用户登录后进行注销（自删除）所以通过token获取自身card
        * */
        Map<String, Object> userInfo = ThreadLocalUtil.get();
        if (userInfo == null || !userInfo.containsKey("card")) {
            return Result.error("未获取到用户信息");
        }
        String card = (String) userInfo.get("card");
        userService.delete(card);
        return Result.success("注销成功");
    }
    /**
     * 用户登录。
     * @param card 身份证号
     * @param password 密码
     * @return Result 登录结果
     */
   /* @PostMapping("/login")     //登录功能
    public Result login(String card, String password) {
        User user = userService.findByCard(card); // 获取用户对象
        if (user == null) {
            return Result.error("用户不存在");
        }
        // 使用 bcrypt 验证用户和密码
        boolean isValid = userService.validatePassword(card, password);
        if (!isValid) {
            return Result.error("用户名或密码错误，请核对后重新输入");
        }
        // 生成 JWT token
        Map<String, Object> claims = new HashMap<>();
        *//* 用户的 ID *//*
        claims.put("id", user.getId());
        *//* 用户的账号 *//*
        claims.put("card", user.getCard());
        //获取token
        String token = JWTUtil.genToken(claims);
        // 将用户信息存储到 ThreadLocal 中
        Map<String, Object> userInfo = new HashMap<>();
        userInfo.put("card", user.getCard());
        ThreadLocalUtil.set(userInfo);
        return Result.success(token);
    }*/
}
