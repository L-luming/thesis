package com.thesis.controller;

import com.thesis.Pojo.*;
import com.thesis.Utils.JWTUtil;
import com.thesis.Utils.ThreadLocalUtil;
import com.thesis.service.RootService;
import com.thesis.service.UserService;
import com.thesis.service.WorkerService;
import jakarta.annotation.Resource;
import org.springframework.security.crypto.bcrypt.BCrypt;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
/**
 * 控制器，用于处理与登录相关的请求。
 */
@RestController
public class LoginController {
    @Resource
    private final UserService userService;
    @Resource
    private final WorkerService workerService;
    @Resource
    private final RootService rootService;

    public LoginController(UserService userService, WorkerService workerService, RootService rootService) {
        this.userService = userService;
        this.workerService = workerService;
        this.rootService = rootService;
    }
    /**
     * 登录功能。
     * @return Result 登录结果
     */
    @PostMapping("/login")     // 登录功能
    public Result login(@RequestBody LoginRequest loginRequest) {
        String card = loginRequest.getCard();
        String staffId = loginRequest.getStaffId();
        String account = loginRequest.getAccount();
        String password = loginRequest.getPassword();
        // 先尝试作为用户登录
        User user = userService.findByCard(card);
        if (user != null) {
            boolean isValid = userService.validatePassword(card, password);
            if (isValid) {
                // 生成 JWT token
                Map<String, Object> claims = new HashMap<>();
                claims.put("id", user.getId());
                claims.put("card", user.getCard());
                claims.put("userType", "user");
                String token = JWTUtil.genToken(claims);
                // 将用户信息存储到 ThreadLocal 中
                Map<String, Object> userInfo = new HashMap<>();
                userInfo.put("card", user.getCard());
                ThreadLocalUtil.set(userInfo);
                return Result.success(token);
            } else {
                return Result.error("用户名或密码错误，请核对后重新输入");
            }
        }

        // 尝试作为工作人员登录
        Worker worker = workerService.findByStaffId(staffId);
        if (worker != null) {
            boolean isValid = workerService.validatePassword(staffId, password);
            if (isValid) {
                // 生成 JWT token
                Map<String, Object> claims = new HashMap<>();
                claims.put("id", worker.getId());
                claims.put("staffId", worker.getStaffId());
                claims.put("userType", "worker");
                String token = JWTUtil.genToken(claims);
                // 判断是否使用初始密码
                boolean isInitialPassword = BCrypt.checkpw("123456", worker.getPassword());
                if (isInitialPassword) {
                    return Result.success(token, "请尽快修改初始密码");
                } else {
                    return Result.success(token);
                }
            } else {
                return Result.error("用户名或密码错误，请核对后重新输入");
            }
        }

        // 尝试作为管理员登录
        Root root = rootService.findByAccount(account);
        if (root != null) {
            boolean isValid = rootService.validatePassword(account, password);
            if (isValid) {
                // 生成 JWT token
                Map<String, Object> claims = new HashMap<>();
                claims.put("id", root.getId());
                claims.put("account", root.getAccount());
                claims.put("userType", "root");
                String token = JWTUtil.genToken(claims);
                // 将用户信息存储到 ThreadLocal 中
                Map<String, Object> userInfo = new HashMap<>();
                userInfo.put("account", root.getAccount());
                ThreadLocalUtil.set(userInfo);
                return Result.success(token);
            } else {
                return Result.error("用户名或密码错误，请核对后重新输入");
            }
        }

        return Result.error("用户不存在");
    }
}
