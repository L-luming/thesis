package com.thesis.controller;

import com.thesis.Pojo.Buy;
import com.thesis.Pojo.Result;
import com.thesis.service.BuyService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.*;

import java.util.List;
/**
 * 控制器，用于处理与供货单相关的请求。
 */
@RestController
@RequestMapping("/buy")
public class BuyController {
    @Resource
    private BuyService buyService;

    /**
     * 获取所有供货单。
     * @return Result 包含供货单列表
     */
    @GetMapping("/list")
    public Result list(){
        List<Buy> list = buyService.list();
        return Result.success(list);
    }
    /**
     * 根据供货商获取供货单详情。
     *
     * @param vender 供货商名称
     * @return Result 包含供货单详情列表
     */
    @GetMapping("/vender")
    public List<Buy> vender(@RequestParam String vender){
        //输入供货商详情可以定位供货单
        return  buyService.findByVender(vender);
    }

    /**
     * 根据 ID 获取供货单详情。
     * @param id 供货单 ID
     * @return Result 包含供货单详情列表
     */
    @GetMapping("/detail/{id}")
    public Result detail(@PathVariable int id){
        //输入供货商详情可以定位供货单
        Buy buy = buyService.findById(id);
        return Result.success(buy);
    }
}
