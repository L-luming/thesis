package com.thesis.controller;

import com.thesis.service.BuyDetailService;
import jakarta.annotation.Resource;
import org.springframework.web.bind.annotation.RestController;
/**
 * 控制器，用于处理与供货单详情相关的请求。
 */
@RestController
public class BuyDetailController {
    @Resource
    private BuyDetailService buyDetailService;

}
