package com.thesis.mapper;

import com.thesis.Pojo.Prescription;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
/**
 * 数据访问层接口，用于操作药单表。
 */
@Mapper
public interface PrescriptionMapper {
    /**
     * 获取所有药单。
     * @return List 包含所有药单
     */
    List<Prescription> list();

    /**
     * 获取当前用户的药单。
     * @param card 用户身份证号
     * @return List 包含当前用户的药单
     */
    List<Prescription> userList(@Param("id") int id);

    /**
     * 根据 ID 获取药单及其详情。
     * @param id 药单 ID
     * @return Prescription 包含药单及其详情
     */
    Prescription getById(int id);

}
