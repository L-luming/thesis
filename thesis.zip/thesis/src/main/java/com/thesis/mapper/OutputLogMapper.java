package com.thesis.mapper;

import com.thesis.Pojo.OutputLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
/**
 * 数据访问层接口，用于操作出库日志表。
 */
@Mapper
public interface OutputLogMapper {
    /**
     * 插入出库日志。
     * @param outputLog 出库日志信息
     */
    void insertOutputLog(@Param("outputLog") OutputLog outputLog);

    /**
     * 更新出库日志。
     * @param outputLog 出库日志信息
     */
    void updateOutputLog(@Param("outputLog") OutputLog outputLog);

    /**
     * 获取所有出库日志。
     * @return List 包含所有出库日志
     */
    List<OutputLog> list();

    /**
     * 根据 ID 获取出库日志详情。
     * @param id 出库日志 ID
     * @return List 包含出库日志详情
     */
    List<OutputLog> detail(int id);
}