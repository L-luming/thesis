package com.thesis.mapper;

import com.thesis.Pojo.Root;
import org.apache.ibatis.annotations.Mapper;
/**
 * 数据访问层接口，用于操作管理员表。
 */
@Mapper
public interface RootMapper {
    /**
     * 根据管理员账号获取管理员信息。
     * @param account 管理员账号
     * @return Root 管理员信息
     */
    Root findByAccount(String account);
}
