package com.thesis.mapper;

import com.thesis.Pojo.Buy;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * 数据访问层接口，用于操作供货单表。
 */
@Mapper
public interface BuyMapper {
    /**
     * 获取所有供货单。
     * @return List 包含所有供货单
     */
    List<Buy> list();

    /**
     * 根据供货商获取供货单详情。
     * @param vender 供货商名称
     * @return List 包含供货单详情
     */
    List<Buy> findByVender(String vender);

    /**
     * 根据 ID 获取供货单。
     * @param id 供货单 ID
     * @return List 包含供货单
     */
    Buy findById(int id);

}
