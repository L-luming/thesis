package com.thesis.mapper;

import com.thesis.Pojo.Worker;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
/**
 * 数据访问层接口，用于操作工作人员表。
 */
@Mapper
public interface WorkerMapper {
    /**
     * 根据身份证号获取工作人员信息。
     * @param card 身份证号
     * @return Worker 工作人员信息
     */
    Worker findByCard(String card);

    /**
     * 添加工作人员。
     */
    void add(Worker worker);

    /**
     * 根据工作人员账号获取工作人员信息。
     * @param staffId 工作人员账号
     * @return Worker 工作人员信息
     */
    Worker findByStaffId(String staffId);

    /**
     * 更新工作人员手机号。
     * @param phone 新手机号
     * @param staffId 工作人员账号
     */
    void update(String phone, String staffId);

    /**
     * 更新工作人员密码。
     * @param newpwd 新密码
     * @param staffId 工作人员账号
     */
    void updatepassword(String newpwd, String staffId);

    /**
     * 删除工作人员。
     * @param staffId 工作人员账号
     */
    void delete(String staffId);

    /**
     * 获取所有工作人员。
     * @return List 包含所有工作人员
     */
    List<Worker> getAllWorkers();

    void updateStaffId(String staffId, Integer id);
}