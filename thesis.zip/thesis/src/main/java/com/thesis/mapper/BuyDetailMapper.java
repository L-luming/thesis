package com.thesis.mapper;

import com.thesis.Pojo.BuyDetail;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
/**
 * 数据访问层接口，用于操作供货单详情表。
 */
@Mapper
public interface  BuyDetailMapper {
    /**
     * 根据供货单 ID 获取供货单详情。
     * @param buyDetailId 供货单详情 ID
     * @return List 包含供货单详情
     */
    List<BuyDetail> getDetail(@Param("buyDetailId")int buyDetailId);
}
