package com.thesis.mapper;

import com.thesis.Pojo.InputLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 数据访问层接口，用于操作入库日志表。
 */
@Mapper
public interface InputLogMapper {
    /**
     * 插入入库日志。
     * @param inputlog 入库日志信息
     */
    void insertInputLog(@Param("inputLog") InputLog inputlog);

    /**
     * 更新入库日志。
     * @param inputlog 入库日志信息
     */
    void updateInputLog(@Param("inputLog") InputLog inputlog);

    /**
     * 获取所有入库日志。
     * @return List 包含所有入库日志
     */
    List<InputLog> list();

    /**
     * 根据 ID 获取入库日志详情。
     * @param id 入库日志 ID
     * @return List 包含入库日志详情
     */
    InputLog detail(int id);
}