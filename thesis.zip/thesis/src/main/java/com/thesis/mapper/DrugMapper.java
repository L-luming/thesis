package com.thesis.mapper;

import com.thesis.Pojo.Drug;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 数据访问层接口，用于操作药品表。
 */
@Mapper
public interface DrugMapper {
    /**
     * 获取所有药品。
     * @return List 包含所有药品
     */
    List<Drug> list();

    /**
     * 根据名称查找药品。
     * @param name 药品名称
     * @return int 药品数量
     */
    int findByName(String name);

    /**
     * 根据 ID 获取药品详情。
     * @param id 药品 ID
     * @return List 包含药品详情
     */
    List<Drug> detail(int id);

    /**
     * 获取带有锁的药品信息。
     * @param drugId 药品 ID
     * @return Drug 药品信息
     */
    Drug getDrugWithLock(@Param("drugId") int drugId);

    /**
     * 更新药品库存。
     * @param drug 药品信息
     */
    void updateDrugStore(@Param("drug") Drug drug);

    /**
     * 根据 ID 获取药品信息。
     * @param drugId 药品 ID
     * @return Drug 药品信息
     */
    Drug getDrugById(int drugId);

    List<Drug> findById(int id);
}
