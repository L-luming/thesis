package com.thesis.mapper;

import com.thesis.Pojo.PrescriptionDetail;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 数据访问层接口，用于操作药单详情表。
 */
@Mapper
public interface PrescriptionDetailMapper {
    /**
     * 根据药单 ID 获取药单详情。
     * @param prescriptionId 药单 ID
     * @return List 包含药单详情
     */
    List<PrescriptionDetail> getDetailsByPrescriptionId(@Param("prescriptionId") int prescriptionId);
}
